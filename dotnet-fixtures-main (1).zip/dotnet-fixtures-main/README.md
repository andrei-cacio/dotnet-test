# dotnet-fixtures

This is a repository that contains various dotnet fixtures to use for testing. They can be used for both manual and automated testing. Contributions welcome.
